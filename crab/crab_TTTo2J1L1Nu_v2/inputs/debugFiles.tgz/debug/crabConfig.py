from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'TTTo2J1L1Nu_v2'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'PSet.py'
config.JobType.inputFiles = ['crab_script_copy.py', '../scripts/keep_and_drop.txt']
config.JobType.sendVenvFolder = False
config.JobType.pluginName = 'Analysis'
config.JobType.scriptExe = 'crab_script.sh'
config.JobType.maxJobRuntimeMin = 2700
config.section_('Data')
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/apuglia'
config.Data.allowNonValidInputDataset = True
config.Data.inputDataset = '/TTTo2J1L1Nu_CP5_13p6TeV_powheg-pythia8/Run3Winter22NanoAOD-122X_mcRun3_2021_realistic_v9-v1/NANOAODSIM'
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'TTTo2J1L1Nu'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T2_IT_Pisa'
