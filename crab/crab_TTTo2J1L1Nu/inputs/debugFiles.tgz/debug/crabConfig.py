from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = 'TTTo2J1L1Nu'
config.section_('JobType')
config.JobType.psetName = 'PSet.py'
config.JobType.scriptExe = 'crab_script.sh'
config.JobType.maxJobRuntimeMin = 2700
config.JobType.pluginName = 'Analysis'
config.JobType.sendVenvFolder = False
config.JobType.inputFiles = ['crab_script_copy.py', '../scripts/keep_and_drop.txt']
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.allowNonValidInputDataset = True
config.Data.publication = False
config.Data.unitsPerJob = 2000
config.Data.inputDataset = '/TTTo2J1L1Nu_CP5_13p6TeV_powheg-pythia8/Run3Winter22NanoAOD-122X_mcRun3_2021_realistic_v9-v1/NANOAODSIM'
config.Data.outLFNDirBase = '/store/user/apuglia'
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'TTTo2J1L1Nu'
config.section_('Site')
config.Site.storageSite = 'T2_IT_Pisa'
